/// <reference path="../../../../tools/typings/x2js/xml2json.d.ts" />
namespace dmitriApp.services {

    export class AuthService {
        serviceBase: string = '/api/auth/';
        user: shared.IUser = {
            loginPath: '/login',
            isAuthenticated: false,
            roles: null
        };

        static $inject = ['$rootScope', '$http', '$soap'];

        constructor(private $rootScope: ng.IRootScopeService,
            private $http: ng.IHttpService, private $soap) {
            
            this.$rootScope = $rootScope;
            this.$http = $http;
            this.$soap = $soap;
        }

        login(username: string, password: string) {
            var loggedIn = false;
            var x2js = new X2JS();
            var xmlString =
                "<LOGIN_INPUT>" +
                "<COMMONPARAMETERS>" +
                "<TRANSACTION_ID/>" +
                "<CONFIRMATION_ID/>" +
                "<SOURCE_SYSTEM_CODE>RS</SOURCE_SYSTEM_CODE>" +
                "<TARGET_SYSTEM_CODE>RS</TARGET_SYSTEM_CODE>" +
                "<SYSTEM_ERROR/>" +
                "<ERROR_COUNT/>" +
                "<APPLICATIONERRORS/>" +
                "<USERDEFINEDFIELDS/>" +
                "</COMMONPARAMETERS>" +
                "<APPLICATIONPARAMETERS>" +
                "<SESSIONID>null</SESSIONID>" +
                "<USERCREDENTIALS>" +
                "<LOGGEDUSER>" +
                "<NAME>" + username + "</NAME>" +
                "<PASSWORD>" + password + "</PASSWORD>" +
                "<CLIENTCODE/>" +
                "<DOMAIN/>" +
                "</LOGGEDUSER>" +
                "<ALIAS>" +
                "<NAME>" + username + "</NAME>" +
                "<CLIENTCODE/>" +
                "</ALIAS>" +
                "</USERCREDENTIALS>" +
                "<DATABASEINSTANCE/>" +
                "<LOGTRANSACTION>Y</LOGTRANSACTION>" +
                "</APPLICATIONPARAMETERS>" +
                "<CONTRACTPARAMETERS/>" +
                "</LOGIN_INPUT>";
            var url = "https://rwebsrvdev.crawco.com/WebServicesQuestC/util.asmx";
            var jsonObj = x2js.xml_str2json<any>(xmlString);

            var webLoginResponse = this.$soap.post(url, "Login", [xmlString]);
            
            if (false) {
                loggedIn = true;
            } else {
                console.log('broadcasting EVENT_DISPLAY_NOTIFICATION');
                //this invokes password invalid dialog
                this.$rootScope.$broadcast('EVENT_ALERT_PWDINVALID', { type: 'error', message: 'Invalid password' });
                loggedIn = false;

                //this invokes password will expire modal
                //this.$rootScope.$broadcast('EVENT_ALERT_PWDEXPIRED', {type:'expired', message: 'Password has expired'});
            }
            this.changeAuth(loggedIn);
            return loggedIn;
        }

        logout(): ng.IPromise<boolean> {
            return this.$http.get(this.serviceBase + 'logout').then(
                (results: ng.IHttpPromiseCallbackArg<boolean>) => {
                    var loggedIn = !results.data;
                    this.changeAuth(loggedIn);
                    return loggedIn;
                });
        }

        redirectToLogin() {
            this.$rootScope.$broadcast('redirectToLogin', null);
        }

        changeAuth(loggedIn: boolean) {
            this.user.isAuthenticated = loggedIn;
            this.$rootScope.$broadcast('loginStatusChanged', loggedIn);
        }

    }

    angular.module('dmitriApp').service('dmitriApp.services.authService', AuthService);
}