namespace dmitriApp {
    
    export class ConfigureApplication {
        static $inject = ['$routeProvider', '$httpProvider'];
        constructor ($routeProvider: ng.route.IRouteProvider, $httpProvider: ng.IHttpProvider) {
            dmitriApp.Routes.configure($routeProvider);
        }
    }

}

angular.module('dmitriApp',
    ['ngRoute', 'ngAnimate', 'ui.bootstrap', 'ngCookies', 'gettext', 'angularSoap'])
    .config(dmitriApp.ConfigureApplication);
