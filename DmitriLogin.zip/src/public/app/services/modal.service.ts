namespace dmitriApp.services {

    export class ModalService {

    }

    angular.module('dmitriApp').service('dmitriApp.services.modalService', ModalService);

}