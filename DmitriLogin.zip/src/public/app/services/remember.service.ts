namespace dmitriApp.services {

    export class RememberService {
        static $inject = ['$rootScope', '$cookies'];
        constructor(private $rootScope: ng.IRootScopeService, private $cookies) {
        }
        
        remember (username) {
            var date = new Date();
            date.setDate(date.getDate() + 365);
            this.$cookies.put('un', username, {expires: date.toString()});
        }
        
        forget () {
            this.$cookies.remove('un');
        }
        
        fetchUsername () {
            return this.$cookies.get('un');
        }
    }

    angular.module('dmitriApp').service('dmitriApp.services.rememberService', RememberService);
}