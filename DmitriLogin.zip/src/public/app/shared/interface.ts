module dmitriApp.shared {

    export interface IRouteParamsServiceWithRedirect extends ng.route.IRouteParamsService {
        redirect: boolean;
    }

    export interface IHttpPromiseCallbackErrorArg extends ng.IHttpPromiseCallbackArg<any> {
         message: string;
    }
    
    export interface IUser {
        loginPath: string;
        isAuthenticated: boolean;
        roles: string[];
    }


}
