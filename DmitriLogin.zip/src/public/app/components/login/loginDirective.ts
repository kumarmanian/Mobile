module dmitriApp {
    'use strict';

    // contains directive for invalid/confirm password

    interface IDialogInvalidPasswordScope extends ng.IScope {
        value: number;
        closeDialog: any;
    }

    interface IModalExpiredPassword extends ng.IScope {
        close: any;
        save: any;
    }

    export class DialogInvalidPassword implements ng.IDirective {

        public template: string = `\n\
            <div role="dialog" id="modalIncorrectPassword" class="modal fade in app-modal">
                <div class="modal-dialog incorrect-pass-popup">
                    <!-- Modal content-->
                    <div class="modal-content terms">
                        <div class="modal-body">
                            <h4 class="incorrect-pass">Password is incorrect. Please try again.</h4>
                        </div>
                        <div class="modal-footer app-footer">
                            <button data-ng-click="closeDialog()" data-dismiss="modal" class="btn btn-default full-width" type="button">OK</butto>
                        </div>
                    </div>
                </div>
            </div>`;
        public scope = {};
        public restrict: string = 'EA';

        constructor(private $rootScope: ng.IRootScopeService) {

        }

        public link: ng.IDirectiveLinkFn = (scope: IDialogInvalidPasswordScope,
            element: ng.IAugmentedJQuery,
            attrs: ng.IAttributes) => {

            this.$rootScope.$on('EVENT_ALERT_PWDINVALID', function(event, messageData) {
                console.log('heard broadcast EVENT_ALERT_PWDINVALID');
                $('#modalIncorrectPassword').show();
            });

            scope.closeDialog = function() {
                $('#modalIncorrectPassword').hide();
            };
        };
    }

    export class ModalExpiredPassword implements ng.IDirective {

        public templateUrl: string = 'app/components/login/password.expired.html';
        public scope = {};
        public restrict: string = 'EA';

        constructor(private $rootScope: ng.IRootScopeService) {

        }

        public link: ng.IDirectiveLinkFn = (scope: IModalExpiredPassword,
            element: ng.IAugmentedJQuery,
            attrs: ng.IAttributes) => {

            this.$rootScope.$on('EVENT_ALERT_PWDEXPIRED', function(event, messageData) {
                $('#modalExpirePassword').show();
            });

            scope.close = function() {
                $('#modalExpirePassword').hide();
            };

            scope.save = function() {
                console.log(attrs);
            };
        };
    }

    angular.module('dmitriApp')
        .directive('dialogInvalidPassword',
        ['$rootScope', ($rootScope: ng.IRootScopeService) => new dmitriApp.DialogInvalidPassword($rootScope)])
        .directive('modalExpiredPassword',
        ['$rootScope', ($rootScope: ng.IRootScopeService) => new dmitriApp.ModalExpiredPassword($rootScope)]);
}