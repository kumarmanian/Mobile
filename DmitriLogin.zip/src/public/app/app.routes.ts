namespace dmitriApp {

    export class Routes {
        static configure($routeProvider: ng.route.IRouteProvider) {
            var viewBase: string = 'app/components/';

            $routeProvider
                .when('/', {
                    controller: 'dmitriApp.LoginController',
                    templateUrl: viewBase + 'login/login.html',
                    controllerAs: 'vm'
                })
                .when('/dashboard', {
                    controller: 'dmitriApp.DashboardController',
                    templateUrl: viewBase + 'dashboard/dashboard.html'
                })
                .otherwise({ redirectTo: '/' });
        }
    }
}
