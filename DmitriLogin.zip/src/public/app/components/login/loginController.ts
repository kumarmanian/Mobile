namespace dmitriApp {

    class LoginController {
        path = '/';
        username = null;
        password = null;
        errorMessage = null;
        displayPassword = null;
        rememberMeFlag = 0;
        
        //inject dependencies
        static $inject = ['$routeParams', '$location', 'dmitriApp.services.authService', 'dmitriApp.services.rememberService'];
        constructor(private $routeParams: shared.IRouteParamsServiceWithRedirect,
            private $location: ng.ILocationService,
            private authService: services.AuthService,
            private rememberService: services.RememberService) {

            this.setUsername();
        }

        login() {

            if (this.rememberMeFlag) {
                this.rememberService.remember(this.username);
            }

            var status = this.authService.login(this.username, this.password);

            //$routeParams.redirect will have the route
            //they were trying to go to initially
            if (!status) {
                this.errorMessage = 'Unable to login';
                return;
            }

            if (status && this.$routeParams) {
                this.path = this.path + 'dashboard';
                this.$location.path(this.path);
            }
        }

        rememberMe() {
            //rememberMe
            if (this.rememberMeFlag) {
                this.rememberMeFlag = 0;
            } else {
                this.rememberMeFlag = 1;
            }
        }

        setUsername() {
            var usr = this.rememberService.fetchUsername();
            if (usr) {
                this.username = usr;
            }
        }
    }

    angular.module('dmitriApp').controller('dmitriApp.LoginController', LoginController);

}
