namespace dmitriApp.constants {
    
    export class ErrorCodesConstant {
       
       static get Default(): any {
             return {
                 ERROR_LOG: 'The login credentials you entered are not valid',
                 ERROR_ACCT: 'The login credentials you entered are not valid'
             };
         };
    }

    angular.module('dmitriApp').constant('dmitriApp.constants.errorCodesConstant', ErrorCodesConstant);
}