namespace dmitriApp {

    class DashboardController {

        static $inject = ['$routeParams', '$location', 'dmitriApp.services.authService'];

    }

    angular.module('dmitriApp').controller('dmitriApp.DashboardController', DashboardController);
}