namespace dmitriApp.services {
    export class DataService {
        

    }
    angular.module('dmitriApp').service('dmitriApp.services.dataService', DataService);
}
